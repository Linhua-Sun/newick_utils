die "Usage: perl $0 <in.snp> <window> <out>\n" unless @ARGV==3;

use PerlIO::gzip;

my %all;

if($ARGV[0]=~/\.gz/){
    open IN,'<gzip',"$ARGV[0]"||die "$!";
}else{
    open IN,"<$ARGV[0]"||die "$!";
}
open OUT,'>gzip',"$ARGV[-1].gz"||die "$!";
my $sam=0;
while(<IN>){
    chomp;
    my @ff=split /\s+/;
    my $gn=join('',@ff[4..$#ff]);
    $all{$i}="$ff[0]\t$ff[1]\t$ff[2]\t$gn";
    $sam=scalar(@ff)-4;
    $i++;
}
my $num = $i;
close IN;

my $variety=$sam*2;
my $w=$ARGV[1];
my $p=-7;
my $k=4;
my $f=0.7;

for($i=0;$i<$num;$i++){
    my $st=$i-int($w/2);
    my $en=$i+int($w/2);
    if($st<0){
        $st=0;
    }
    if($en>=$num){
        $en=$num-1;
    }
    my $diff = $en - $st;
    my @lr0=split('',(split /\s+/,$all{$i})[-1]);
    my ($chr,$loci,$geno)=(split /\s+/,$all{$i})[0,1,2];
    print OUT "$chr\t$loci\t$geno\t";
    my %lr=();
    for(my $count=0;$count<=$diff;$count++){
        @{$lr{$count}}=split('',$all{$st+$count});
    }
    for(my $j=0;$j<$variety;$j++){
        if($lr0[$j] eq "-"){
            my %z=();
            my %sort=();
            my %zmax=();
            my %lmax=();
            for(my $lm=$j-int($w/2);$lm<$j+int($w/2);$lm++){
                my $l;
                if($j+int($w/2)<=$variety){
                    $l=$lm;
                }else{
                    $l=$lm-$variety;
                }
                if($lr0[$l] ne "-" && $l ne $j){
                    my $count0=0;
                    for(my $ct=0;$ct<=$diff;$ct++){
                        if(${$lr{$ct}}[$j] eq "-"|| ${$lr{$ct}}[$l] eq "-"){
                            $z{$l}+=0.5;
                        }elsif(${$lr{$ct}}[$j] eq ${$lr{$ct}}[$l]){
                            $z{$l}+=1;
                        }else{
                            $z{$l}+=$p;
                            $count0++;
                            if($count0>5){
                                delete $z{$l};
                                last;
                            }
                        }
                    }
                    for(my $nn=0;$nn<5;$nn++){
                        if($z{$l}>$zmax{$nn}){
                            $zmax{$nn}=$z{$l};
                            $lmax{$nn}=$l;
                        }
                    }
                }
            }
            my @top=();
            my $newk=0;
            for(my $ll=0;$ll<$k;$ll++){
                if(exists $zmax{$ll}){
                    push @top,$lr0[$lmax{$ll}];
                    $newk++;
                }
            }
            my %topf=();
            for($lm=0;$lm<$newk;$lm++){
                $topf{$top[$lm]}++;
            }
            my $shift=0;
            foreach $key(keys %topf){
                my $temp = $topf{$key}/$newk;
                if($temp>=$f){
                    print OUT "$key";
                    $shift=1;
                    last;
                }
            }
            if($shift==0){
                print OUT "-";
            }
        }else{
            print OUT "$lr0[$j]";
        }
    }
    print OUT "\n";
}
close OUT;
