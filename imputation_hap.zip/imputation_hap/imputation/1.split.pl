die "Usage: perl $0 <in.snp> <window> <outDir>\n" unless @ARGV==3;
# window is the number of markers should be considered during imputation
# suggested window: 20

my %hash;

if($ARGV[0]=~/\.gz/){
    use PerlIO::gzip;
    open IN,'<gzip',"$ARGV[0]"||die "$!";
}else{
    open IN,"<$ARGV[0]"||die "$!";
}
while(<IN>){
    chomp;
    my @ff=split /\s+/;
    my $r=int($ff[1]/1000000);
    if($ff[1]>=$r*1000000-100000 && $ff[1]<=($r+1)*1000000+100000){
        push @{$hash{$r}},$_;
    }
}
close IN;

my @pp=split /\//,$0;
my $pwd=join("/",@pp[0..$#pp-1]);

open TO,">$ARGV[-1].im.sh"||die "$!";
foreach my $k(sort {$a<=>$b} keys %hash){
    open OT,'>gzip',"$ARGV[-1].$k.snp.gz"||die "$!";
    my @mm=@{$hash{$k}};
    for(my $i=0;$i<@mm;$i++){
        print OT "$mm[$i]\n";
    }
    close OT;
    if($k%15==0){
        print TO "perl $pwd/k-nearest_imputation.pl $ARGV[-1].$k.snp.gz $ARGV[1] $ARGV[-1].$k.snp.im\n";
    }else{
        print TO "perl $pwd/k-nearest_imputation.pl $ARGV[-1].$k.snp.gz $ARGV[1] $ARGV[-1].$k.snp.im &\n";
    }
}
close TO;

print "please run the $ARGV[-1].im.sh in $ARGV[-1]\n";
