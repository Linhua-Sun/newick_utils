die "Usage: perl $0 <in.snp> <in.info> <out>\n" unless @ARGV==3;

use PerlIO::gzip;

my %hash;

open AN,'<gzip',"$ARGV[1]"||die "$!";
while(<AN>){
    chomp;
    my @an=split /\s+/;
    my $s1;
    if($_=~/Os/){
        for(my $ii=2;$ii<@an;$ii++){
            if($an[$ii]=~/gene/){
                my $ge=(split /:/,$an[$ii])[0];
                $s1="$an[0]\t$an[1]";
            	push @{$hash{$s1}},$ge;
            }
        }
    }
}
close AN;

open IN,'<gzip',"$ARGV[0]"||die "$!";
open OT,'>gzip',"$ARGV[-1].gz"||die "$!";
while(<IN>){
    chomp;
    my @ff=split /\s+/;
    my $s2="$ff[0]\t$ff[1]";
    next if(!exists $hash{$s2});
    my @gg=split /\//,$ff[2];
    foreach my $g(@{$hash{$s2}}){
        print OT "$ff[0]\t$g\t$ff[1]\t$gg[0]\t$gg[1]\t";
        for(my $i=4;$i<@ff;$i++){
            if($ff[$i]=~/$gg[0]/ && $ff[$i]!~/$gg[1]/){
                print OT "1 0 0 ";
            }elsif($ff[$i]=~/$gg[1]/ && $ff[$i]!~/$gg[0]/){
                print OT "0 0 1 ";
            }elsif($ff[$i]=~/-/){
                print OT "0 0 0 ";
            }else{
                print OT "0 1 0 ";
            }
        }
        print OT "\n";
    }
}
close IN;
close OT;
