die "Usage: perl $0 <in.trans.snp>\n" unless @ARGV==1;

my %hash;
my %hash1;
my $n=0;

use PerlIO::gzip;

open SN,'<gzip',"$ARGV[0]"||die "$!";
my $chr=(split /\./,$ARGV[0])[0];
system("mkdir $chr");
while(<SN>){
    chomp;
    my @gg=split /\s+/,$_;
    open GN,">>$gg[1].gen"||die "$!";
    print GN "$_\n";
    $n=(scalar(@gg)-5)/3;
    $hash{$gg[1]}++;
    for(my $i=0;$i<$n;$i++){
        my $ii=$i*3+5;
        my $s1="$gg[1]\t$i";
        if($gg[$ii]+$gg[$ii+1]+$gg[$ii+2]==0){
            $hash1{$s1}++;
        }
    }
}
close SN;

my @pp=split /\//,$0;
my $pwd=join("/",@pp[0..$#pp-1]);

foreach my $k(keys %hash){
    open GG,"<$k.gen"||die "$!";
    open SM,">$k.sample"||die "$!";
    open OT,">$k.gen.st"||die "$!";
    print SM "ID_1 ID_2 missing\n0 0 0\n";
    my %sm;
    for(my $j=0;$j<$n;$j++){
        my $s2="$k\t$j";
        next if($hash1{$s2}/$hash{$k}>0.8);
        print SM "SAM$j\tSAM$j\t0\n";
        $sm{$j}=1;
    }
    while(<GG>){
        chomp;
        my @mm=split /\s+/,$_;
        print OT "$mm[0]\t$mm[1]\t$mm[2]\t$mm[3]\t$mm[4]\t";
        for(my $jj=0;$jj<$n;$jj++){
            if(exists $sm{$jj}){
                print OT "$mm[$jj*3+5] $mm[$jj*3+6] $mm[$jj*3+7]\t";
            }
        }
        print OT "\n";
    }
    close OT;
    close SM;
    system("mv $k.gen.st $k.gen");
    system("$pwd/./shapeit -G $k -O $k.hp");
    system("rm *.mm *.log");
}
