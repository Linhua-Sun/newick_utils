die "Usage: perl $0 <in.candidate> <all.gff3> <total depth threshold> <depth for each sample> <chr>\n" unless @ARGV==5;

my %hash;
use PerlIO::gzip;

if($ARGV[0]=~/\.gz/){
    open IN,'<gzip',"$ARGV[0]"||die "$!";
}else{
    open IN,"<$ARGV[0]"||die "$!";
}
while(<IN>){
    chomp;
    next if($_=~/^#/);
    my @can=split /\s+/,$_;
    next if($can[0] ne $ARGV[-1]);
    next if(length($can[3])!=1 || length($can[4])!=1);
    my $dp=(split /;/,(split /DP=/,$can[7])[-1])[0];
    next if($dp<$ARGV[2]);
    my $ss="$can[0]\t$can[1]";
    my $inf="$can[3]/$can[4]\t$dp";
    for(my $i=9;$i<@can;$i++){
        my $gn=(split /:/,$can[$i])[0];
        my @dd=split /,/,(split /:/,$can[$i])[1];
        my $gg;
        if($gn eq "0/0"){
            if($dd[0]>=$ARGV[3]){
                $gg="$can[3]"."$can[3]";
            }else{
                $gg="--";
            }
        }elsif($gn eq "0/1" || $gn eq "1/0"){
            if($dd[0]+$dd[1]>=$ARGV[3]){
                $gg="$can[3]"."$can[4]";
            }else{
                $gg="--";
            }
        }elsif($gn eq "1/1"){
            if($dd[0]+$dd[1]>=$ARGV[3]){
                $gg="$can[4]"."$can[4]";
            }else{
                $gg="--";
            }
        }else{
            $gg="--";
        }
        $inf=$inf." ".$gg;
    }
    $hash{$ss}=$inf;
}
close IN;

my %ann;

open GFF,"<$ARGV[1]"||die "$!";
while(<GFF>){
    chomp;
    my @bb=split /\s+/,$_;
    next if($bb[0] ne $ARGV[-1]);
    if($bb[2] eq "gene" || $bb[2] eq "exon" || $bb[2]=~/UTR/i){
        my $name=(split /=/,(split /;/,$bb[8])[0])[-1];
        my $nm="$name:$bb[2]";
        for(my $i=$bb[3]-3000;$i<=$bb[4]+3000;$i++){
            my $s="$bb[0]\t$i";
            if(exists $hash{$s}){
                push @{$ann{$s}},$nm;
            }
        }
    }
}
close GFF;

open OT,'>gzip',"$ARGV[-1].info.gz"||die "$!";
open TO,'>gzip',"$ARGV[-1].cg.snp.gz"||die "$!"; # input of 2.trans_snp.pl and imputation
foreach my $k(keys %hash){
    print OT "$k";
    if(exists $ann{$k}){
        foreach my $j(@{$ann{$k}}){
            print OT "\t$j";
        }
    }
    print OT "\n";
    print TO "$k\t$hash{$k}\n";
}
close OT;
close TO;

my @pp=split /\//,$0;
my $pwd=join("/",@pp[0..$#pp-1]);
system("perl $pwd/2.trans_snp.pl $ARGV[-1].cg.snp.gz $ARGV[-1].info.gz $ARGV[-1].trans.snp &");
